export default function Page() {
  return (
    <main style={{ minHeight: '100vh' }}>
      <iframe
        title="AS Elnagar"
        src="/site/index.html"
        style={{ display: 'block', width: '100%', minHeight: '100vh', border: 0 }}
      />
    </main>
  )
}
