# AS Elnagar

موقع AS Elnagar — تصميم وتنفيذ وتشطيبات.

## تشغيل المشروع محليًا

```bash
pnpm install
pnpm dev
```

ثم افتح `http://localhost:3000`.

## Build للإنتاج

```bash
pnpm build
pnpm start
```

> المشروع مبني باستخدام Next.js، والصفحة الحالية داخل `public/site/index.html` مع ملفات الصور في `public/site/assets/`.
